package com.example.bmiapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var edtWeight: EditText
    private lateinit var edtHeight: EditText
    private lateinit var btnCalculate: Button
    private lateinit var txtResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edtWeight = findViewById(R.id.edtWeight)
        edtHeight = findViewById(R.id.edtHeight)
        btnCalculate = findViewById(R.id.btnCalculate)
        txtResult = findViewById(R.id.txtResult)

        btnCalculate.setOnClickListener {
            val w = edtWeight.text.toString()
            val h = edtHeight.text.toString()

            if (w.isNotEmpty() && h.isNotEmpty()) {
                val weight = w.toDouble()
                val height = h.toDouble() / 100
                val bmi = weight / (height * height)

                var result = "ค่า BMI ของคุณคือ: %.2f\n".format(bmi)

                result += when {
                    bmi < 18.5 -> "อยู่ในเกณฑ์: น้ำหนักน้อย / ผอม"
                    bmi < 24.9 -> "อยู่ในเกณฑ์: ปกติ"
                    bmi < 29.9 -> "อยู่ในเกณฑ์: ท้วม / โรคอ้วนระดับ 1"
                    else -> "อยู่ในเกณฑ์: อ้วนมาก / โรคอ้วนระดับ 2"
                }

                txtResult.text = result
            } else {
                txtResult.text = "กรุณากรอกน้ำหนักและส่วนสูงให้ครบ"
            }
        }
    }
}
